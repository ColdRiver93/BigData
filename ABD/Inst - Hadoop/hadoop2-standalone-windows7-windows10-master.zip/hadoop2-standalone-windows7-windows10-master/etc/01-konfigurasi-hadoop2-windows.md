Folder ./etc/hadoop berisi file-file konfigurasi yang dibutuhkan Hadoop 2 mode standalone Windows 7.
